from django.apps import AppConfig


class LottoresultConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'lottoresult'
